import os, shutil
BASE = r"C:\apex_app\apex_finance\lib"
MAIN = os.path.join(BASE, "main.dart")
shutil.copy2(MAIN, MAIN + ".bak_coa")
print("[OK] Backup done")
f = open(MAIN, "r", encoding="utf-8-sig")
lines = f.readlines()
f.close()
print(f"[i] main.dart: {len(lines)} lines")

# Add import
imp = "import 'screens/coa/coa_screens.dart' as coa;\n"
for i, line in enumerate(lines):
    if "client_list_screens.dart" in line and "import" in line:
        lines.insert(i+1, imp)
        print(f"[OK] Import added at line {i+2}")
        break
else:
    for i, line in enumerate(lines):
        if "legal_screens.dart" in line and "import" in line:
            lines.insert(i+1, imp)
            print(f"[OK] Import added at line {i+2} (fallback)")
            break

# Replace references
reps = 0
coa_classes = [
    "CoaUploadScreen(", "CoaColumnMappingScreen(", "CoaParsedPreviewScreen(",
    "CoaKnowledgeFeedbackScreen(", "CoaQualityReportScreen(", "CoaReviewApprovalScreen("
]
for i, line in enumerate(lines):
    if "coa_screens.dart" in line:
        continue
    n = line
    for cls in coa_classes:
        if cls in n and "class " not in n:
            n = n.replace(cls, "coa." + cls)
            if n != line:
                reps += 1
    lines[i] = n
print(f"[OK] Replaced {reps} references")

# Find COA section boundaries
sd = ed = None
for i, line in enumerate(lines):
    if "COA Upload Screen" in line and "3." in line:
        sd = i
        # Go back to include blank lines before
        while sd > 0 and lines[sd-1].strip() == "":
            sd -= 1
        break

# End = end of file (after all COA classes)
# Find last non-empty line
ed = len(lines)
while ed > 0 and lines[ed-1].strip() == "":
    ed -= 1
ed += 1  # keep one blank line at end

if sd is not None and ed is not None and ed > sd:
    rm = ed - sd
    # Replace with just a newline
    del lines[sd:ed]
    lines.append("\n")
    print(f"[OK] Removed {rm} old lines (COA section)")
else:
    print(f"[WARN] sd={sd} ed={ed}")

f = open(MAIN, "w", encoding="utf-8")
f.write("".join(lines))
f.close()
print(f"[OK] DONE! main.dart: {len(lines)} lines now")
